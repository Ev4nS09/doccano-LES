from django.apps import AppConfig

class PerspectiveTypesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "perspective_types"