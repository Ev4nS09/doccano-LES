from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Count
from django.shortcuts import get_object_or_404
from examples.models import Example
from projects.models import Project
from projects.permissions import IsProjectMember
from .models import Item, Value
from .serializers import ItemSerializer, ValueSerializer

class ItemListCreate(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated & IsProjectMember]
    serializer_class = ItemSerializer  # Make sure this exists

    def get_queryset(self):
        project_id = self.kwargs['project_id']
        return Item.objects.filter(project_id=project_id)

class ValueListCreate(generics.ListCreateAPIView):
    serializer_class = ValueSerializer
    permission_classes = [IsAuthenticated & IsProjectMember]
    
    
    def get_serializer_context(self):
        context = super().get_serializer_context()
        return context

class ValueDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = ValueSerializer
    permission_classes = [IsAuthenticated & IsProjectMember]
